// ===== Tahun footer =====
document.getElementById('year').textContent = new Date().getFullYear();

const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
const hasGSAP = typeof window.gsap !== 'undefined' && typeof window.ScrollTrigger !== 'undefined';
if (hasGSAP) gsap.registerPlugin(ScrollTrigger);

// ===== Sambutan =====
const welcome = document.getElementById('welcome');
const enterBtn = document.getElementById('enterBtn');
let lenis = null;

function enter() {
  if (welcome.classList.contains('hide')) return;
  welcome.classList.add('hide');
  document.body.classList.remove('locked');
  enterBtn.blur();
  initLenis();
  playEntrance();
}
enterBtn.addEventListener('click', enter);
document.addEventListener('keydown', e => {
  if (!welcome.classList.contains('hide') && (e.key === 'Enter' || e.key === 'Escape')) enter();
});
enterBtn.focus();

// ===== Lenis: smooth scroll =====
function initLenis() {
  if (reduceMotion || typeof window.Lenis === 'undefined') return;
  lenis = new Lenis({
    duration: 1.15,
    easing: t => Math.min(1, 1.001 - Math.pow(2, -10 * t)),
    smoothWheel: true,
  });
  if (hasGSAP) {
    lenis.on('scroll', ScrollTrigger.update);
    gsap.ticker.add(time => lenis.raf(time * 1000));
    gsap.ticker.lagSmoothing(0);
  } else {
    const raf = t => { lenis.raf(t); requestAnimationFrame(raf); };
    requestAnimationFrame(raf);
  }
  // Klik menu: scroll halus ke bagian tujuan
  document.querySelectorAll('a[href^="#"]').forEach(a => {
    a.addEventListener('click', e => {
      const target = document.querySelector(a.getAttribute('href'));
      if (!target) return;
      e.preventDefault();
      lenis.scrollTo(target, { offset: -20 });
    });
  });
}

// ===== GSAP: judul muncul per kata saat discroll =====
function splitWords(el) {
  const text = el.textContent.trim();
  el.setAttribute('aria-label', text);
  el.innerHTML = '<span class="t">' + text.split(/\s+/).map(
    w => '<span class="w" aria-hidden="true"><span class="wi">' + w + '</span></span>'
  ).join(' ') + '</span>';
  return el.querySelectorAll('.wi');
}

function playEntrance() {
  if (!hasGSAP || reduceMotion) return;

  // Judul per kata
  document.querySelectorAll('.section-title').forEach(el => {
    const words = splitWords(el);
    gsap.from(words, {
      yPercent: 110,
      opacity: 0,
      duration: .9,
      stagger: .07,
      ease: 'power4.out',
      scrollTrigger: { trigger: el, start: 'top 90%' },
    });
  });

  // Card masuk saat discroll
  document.querySelectorAll('.card').forEach(card => {
    gsap.from(card, {
      y: 48,
      opacity: 0,
      duration: .9,
      ease: 'power3.out',
      clearProps: 'transform',
      scrollTrigger: { trigger: card, start: 'top 92%' },
    });
  });

  ScrollTrigger.refresh();
}

// ===== Hover card (GSAP) =====
if (hasGSAP && !reduceMotion) {
  document.querySelectorAll('.project, .poster, .mini').forEach(el => {
    el.addEventListener('mouseenter', () => gsap.to(el, { y: -6, duration: .45, ease: 'power3.out' }));
    el.addEventListener('mouseleave', () => gsap.to(el, { y: 0, duration: .6, ease: 'power3.out' }));
  });
}

// ===== Liquid glass: pantulan cahaya ikut kursor =====
document.querySelectorAll('.glass').forEach(el => {
  el.addEventListener('pointermove', e => {
    const r = el.getBoundingClientRect();
    el.style.setProperty('--mx', (e.clientX - r.left) + 'px');
    el.style.setProperty('--my', (e.clientY - r.top) + 'px');
  });
});

// ===== Sorot menu sidebar =====
const links = document.querySelectorAll('.side-nav a');
const sections = Array.from(links).map(a => document.querySelector(a.getAttribute('href')));
const observer = new IntersectionObserver(entries => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      links.forEach(a => a.classList.toggle('active', a.getAttribute('href') === '#' + entry.target.id));
    }
  });
}, { rootMargin: '-40% 0px -55% 0px' });
sections.forEach(s => s && observer.observe(s));

// ===== Fitur tambahan =====

// Tema terang / gelap (ikut sistem kalau belum pernah dipilih)
const root = document.documentElement;
const themeBtn = document.getElementById('themeToggle');
function applyTheme(theme) {
  root.setAttribute('data-theme', theme);
  themeBtn.setAttribute('aria-pressed', theme === 'dark' ? 'true' : 'false');
}
let savedTheme = null;
try { savedTheme = localStorage.getItem('theme'); } catch (e) {}
applyTheme(savedTheme || (window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light'));
themeBtn.addEventListener('click', () => {
  const next = root.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
  applyTheme(next);
  try { localStorage.setItem('theme', next); } catch (e) {}
});

// Jam WIB (Asia/Jakarta)
const clockEl = document.getElementById('clock');
const fmt = new Intl.DateTimeFormat('id-ID', { timeZone: 'Asia/Jakarta', hour: '2-digit', minute: '2-digit', hour12: false });
function tick() { if (clockEl) clockEl.textContent = fmt.format(new Date()).replace('.', ':'); }
tick();
setInterval(tick, 15000);

// Progress bar + tombol kembali ke atas
const progress = document.getElementById('progress');
const toTop = document.getElementById('toTop');
function onScroll() {
  const max = document.documentElement.scrollHeight - window.innerHeight;
  const pct = max > 0 ? (window.scrollY / max) * 100 : 0;
  progress.style.width = pct + '%';
  toTop.classList.toggle('show', window.scrollY > 600);
}
window.addEventListener('scroll', onScroll, { passive: true });
onScroll();
toTop.addEventListener('click', () => {
  if (typeof lenis !== 'undefined' && lenis) lenis.scrollTo(0);
  else window.scrollTo({ top: 0, behavior: 'smooth' });
});

// Toast kecil
const toast = document.getElementById('toast');
let toastTimer;
function showToast(msg) {
  toast.textContent = msg;
  toast.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove('show'), 1800);
}

// Salin username Telegram
const copyBtn = document.getElementById('copyBtn');
copyBtn.addEventListener('click', async () => {
  const text = '@luciannovr';
  try {
    await navigator.clipboard.writeText(text);
    showToast('Username disalin: ' + text);
  } catch (e) {
    const ta = document.createElement('textarea');
    ta.value = text; document.body.appendChild(ta); ta.select();
    try { document.execCommand('copy'); showToast('Username disalin: ' + text); }
    catch (err) { showToast('Gagal menyalin, salin manual ya'); }
    ta.remove();
  }
});

// Lightbox poster anime
const lightbox = document.getElementById('lightbox');
const lbImg = document.getElementById('lbImg');
const lbCap = document.getElementById('lbCap');
const lbClose = document.getElementById('lbClose');
function openLightbox(img, caption) {
  lbImg.src = img.src;
  lbImg.alt = img.alt;
  lbCap.textContent = caption;
  lightbox.hidden = false;
  document.body.classList.add('locked');
  lbClose.focus();
}
function closeLightbox() {
  lightbox.hidden = true;
  document.body.classList.remove('locked');
}
document.querySelectorAll('.zoomable').forEach(fig => {
  fig.addEventListener('click', () => {
    const img = fig.querySelector('img');
    const cap = fig.querySelector('figcaption').textContent.trim();
    openLightbox(img, cap);
  });
});
lbClose.addEventListener('click', closeLightbox);
lightbox.addEventListener('click', e => { if (e.target === lightbox) closeLightbox(); });
document.addEventListener('keydown', e => {
  if (e.key === 'Escape' && !lightbox.hidden) closeLightbox();
});
